import React,{Component} from 'react';
import './WeatherDetails.css';
class WeatherDetails extends Component{
render(){
    return(
        <div>
            <h3 className='weather_temperature'>
           {this.props.tempC} °C   <img src={this.props.src}/>
           <div className='description'>{this.props.description}</div>
            </h3>
        </div>
    );
}
}
export default WeatherDetails;