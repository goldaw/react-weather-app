import React, {Component} from 'react';
import cities from './cities.json';
import Autocomplete from 'react-autocomplete';
import './City.css';

class City extends Component{
    constructor(){
        super();
        this.handleChange=this.handleChange.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
        this.state={
            inputField:'',
            value:'',
        };
    }

    submitHandler(evt) {
        evt.preventDefault();
        // pass the input field value to the event handler passed
        // as a prop by the parent (App)
        this.props.handlerFromParant(this.state.value);
        this.setState({
          inputField: '',
          value:'',
        });
      }

    handleChange(event) {
        this.setState({
         value: event.target.value
        });
      }
      render(){
          return(
              <div>
         <form onSubmit={this.submitHandler}>
         Enter city name:<Autocomplete 
            items={cities}
              shouldItemRender={(item, value) => item.name.toLowerCase().indexOf(value.toLowerCase()) > -1}
              getItemValue={item => item.name}
              renderItem={(item, highlighted) =>
              <div
                  key={item.id}
                  style={{ backgroundColor: highlighted ? '#eee' : 'transparent'}}
              >
                  {item.name}
              </div>
        }
        value={this.state.value}
        onChange={this.handleChange}
        onSelect={value => this.setState({ value })}
         />
          <input type="submit" value='search' />
         </form>
         </div>
          );
      }

}
export default City;