import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Data from './Data';


class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
         
          <h1 className="App-title">Current weather and forecasts in your city</h1>
        </header>
        <Data/>
      </div>
    );
  }
}

export default App;
