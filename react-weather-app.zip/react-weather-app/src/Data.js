import React, {Component} from 'react';
import API from '../node_modules/react-fetch';
import Fetch from 'react-fetch';
import WeatherDetails from './WeatherDetails';
import City from './City';
import './Data.css';

class Data extends Component{
  constructor(){
    super();
    
  this.handleData=this.handleData.bind(this);
    this.state={ 
      cityName: '',
      data:[],
      metric:[],
      imperial:[],
      temp:[],
      icon:[],
      msgError:[],
      hasEror:false,
      src:'',
      isCity:false,
      listData:[],
      description:'',
     
    }
  }
  handleData(city) {
   // if(city=="")
   if(city=='' || city=="")
    this.setState({
      isCity:false,
      cityName: '',
    })
     else
     this.callApi(city); 
  }
    callApi(city){
        var location =encodeURIComponent(city); 
        var startUrl='http://api.openweathermap.org/data/2.5/weather?q=';
        var endUrl='&units=metric&appid=60c54d74a76b0de96b25e3d23140c813';
        var url=startUrl+location+endUrl;
        var error1=false;
        fetch(url).then((result) => {
          return result;
        }).then((result)=> {
          if (result.status === "404" || result.status == 404) 
              error1=true;
           return result.json();
        }).then((jsonResult)=>{
          if(error1==true){
            console.log(jsonResult.message);
            this.setState({
              msgError:jsonResult.message,
              hasEror:true,
              isCity:true,
            })
          }
         else{
           console.log(jsonResult);
           var startsrc='http://openweathermap.org/img/w/';
           var endsrc='.png';
            this.setState({ 
            hasEror:false,
            isCity:true,
            cityName: city,
            data:jsonResult.main,
            temp:jsonResult.main.temp,
            icon:jsonResult.weather[0].icon,
            src:startsrc+jsonResult.weather[0].icon+endsrc,
            description:jsonResult.weather[0].description,
          })
         }
        })  .catch(function() {
          console.log('msg error');
      });
      }
        render(){
      if(this.state.isCity==false){
        return(
        <div className='data-wrapper'> 
        <h2>Get current weather in your city:</h2>
          <City handlerFromParant={this.handleData}/>
          <span className='font-span'>No Results</span>
        </div>
       )
      }
      else{
      if(this.state.hasEror){
        return(
        <div className='data-wrapper'> 
        <h2>Get current weather in your city:</h2>
          <City handlerFromParant={this.handleData}/>
          <h2 className='errorCity'>{this.state.msgError}</h2>
        </div>
       )
      }
    else  
        return(
          <div className='data-wrapper'> 
          <h2>Get current weather in your city:</h2>
            <City handlerFromParant={this.handleData}/>
            <h2 >current weather in:<span className='header2'>{this.state.cityName}</span></h2>
            <WeatherDetails tempC={this.state.temp} src={this.state.src} description={this.state.description}/>
          </div> ) 
      }}
      
       
    }
    export default Data;


